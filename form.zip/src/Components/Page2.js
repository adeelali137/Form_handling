import React, { useState } from "react";

export default function Page2({ formdata, setformdata }) {
  return (
    <>
      <div className="page2">
        <div>
          <label htmlFor="">Chp1</label>
          <input
            type="text"
            placeholder="chapter1"
            value={formdata.chapter1}
            onChange={(event) => {
              setformdata({ ...formdata, chapter1: event.target.value });
            }}
          />
        </div>
        <div>
          <label htmlFor="">Chp2</label>
          <input
            type="text"
            placeholder="chapter2"
            value={formdata.chapter2}
            onChange={(event) => {
              setformdata({ ...formdata, chapter2: event.target.value });
            }}
          />
        </div>
        <br />
      </div>
    </>
  );
}
