import React, { useState } from "react";
import { TagsInput } from "react-tag-input-component";

export default function Page1({ formdata, setformdata }) {
  return (
    <>
      <div className="page1">
        <div>
          <label htmlFor="">Course </label>
          <input
            type="text"
            placeholder="Write your course title here..."
            value={formdata.coursetitle}
            onChange={(event) => {
              setformdata({ ...formdata, coursetitle: event.target.value });
            }}
          />
        </div>
        <div>
          <label htmlFor="">Domain</label>
          <input
            type="text"
            placeholder="Domain"
            value={formdata.domain}
            onChange={(event) => {
              setformdata({ ...formdata, domain: event.target.value });
            }}
          />
        </div>
        <div>
          <label htmlFor="">About </label>
          <input
            type="text"
            placeholder="Write about your course here..."
            value={formdata.about}
            onChange={(event) => {
              setformdata({ ...formdata, about: event.target.value });
            }}
          />
        </div>
      </div>
    </>
  );
}
