import React, { useState } from "react";
import Page1 from "./Page1";
import Page2 from "./Page2";

export default function Form() {
  const [page, setpage] = useState(0);
  const [tags, settags] = useState([]);
  const [formdata, setformdata] = useState({
    coursetitle: "",
    domain: "",
    about: "",
    chapter1: "",
    chapter2: "",
  });

  const displayForm = () => {
    if (page === 0) {
      return <Page1 formdata={formdata} setformdata={setformdata} />;
    } else {
      return <Page2 formdata={formdata} setformdata={setformdata} />;
    }
  };

  return (
    <>
      <div className="form_btns">
        <div className="form_page">{displayForm()}</div>
        {page === 0 ? (
          <button
            onClick={() => {
              setpage(page + 1);
            }}
          >
            Next
          </button>
        ) : (
          <button
            onClick={() => {
              console.log(formdata);
            }}
          >
            Submit
          </button>
        )}
      </div>
    </>
  );
}
